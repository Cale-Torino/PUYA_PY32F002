##################################################################
# Patching newer IDE verification (OpenOCD hack no longer works) #
##################################################################

This patch will work either with J-Link or with ST-Link + OpenOCD.

ST-Link GDB server still can't be used with clones, has its own checks on the binary (ST-LINK_gdbserver.exe).
Will crash with the usual "ST-LINK: Could not verify ST device! Abort connection".

Steps for future releases:
- Download and open Recaf (With dependencies): https://github.com/Col-E/Recaf/releases
- Open plugins/com.st.stm32cube.ide.mcu.debug.launch_xxx.jar
- Navigate to com/st/stm32cube/ide/mcu/debug/launch/LaunchSequenceUtil
- Find "public static void stepValidateJEP"
- Right click over the function name, Edit with assembler
- Add RETURN at the first line, press Control+S to save.
- Export program, replace original file.
- Open the IDE, choose either OpenOCD or J-Link, it should work now!

The IDE won't show the popup error anymore.



################################
# Adding custom device support #
################################

- Download the DFP pack, rename to zip, extract and rename the SVD file to something simple, ex, "HK32F030M.SVD". (Or get the SVD file somewhere)

- Copy to plugins\com.st.stm32cube.ide.mcu.productdb.debug_xxx\resources\cmsis\STMicroelectronics_CMSIS_SVD

- Edit plugins\com.st.stm32cube.ide.mcu.productdb_xxx\resources\board_def\stm32targets.xml

- Insert a new mcu block, note how we're defining the cpu architecture and the SVD file we copied earlier!
  Version can be anything, but must be there, the IDE will crash without that field.
  Parent must be stm32xx or the debugger process won't start!
  Choose a stm32 family that uses the came cpu core from other existing entry:

  Cortex M0:  <parent>stm32f0</parent>
  Cortex M0+: <parent>stm32g0</parent>
  Cortex M3:  <parent>stm32f1</parent>
  Cortex M4:  <parent>stm32f4</parent>

For example:

  <mcu>
    <name>HK32K030MF4P6</name>
    <status>Active</status>
    <parent>stm32f0</parent>
    <cpus>
      <cpu>
        <id>0</id>
        <svd>
          <name>HK32F030M.svd</name>
          <version>v1r0</version>
        </svd>
        <cores>
          <core>
            <id>0</id>
            <apnum>0</apnum>
            <type>arm cortex-m0</type>
            <fpu>None</fpu>
          </core>
        </cores>
      </cpu>
    </cpus>
  </mcu>

- 
#include "main.h"
#include "py32f0xx_bsp_clock.h"
#include "delay.h"

// PA1 led
void GPIO_init(void)
{
  LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOA | LL_IOP_GRP1_PERIPH_GPIOB | LL_IOP_GRP1_PERIPH_GPIOF);
  WritePin(RED,1);  WritePin(GREEN,1);
  LL_GPIO_Init(RED_Port,   &(LL_GPIO_InitTypeDef){ RED_Pin, LL_GPIO_MODE_OUTPUT, LL_GPIO_SPEED_FREQ_VERY_HIGH, LL_GPIO_OUTPUT_PUSHPULL, LL_GPIO_PULL_NO });
  LL_GPIO_Init(GREEN_Port, &(LL_GPIO_InitTypeDef){ GREEN_Pin, LL_GPIO_MODE_OUTPUT, LL_GPIO_SPEED_FREQ_VERY_HIGH, LL_GPIO_OUTPUT_PUSHPULL, LL_GPIO_PULL_NO });
  LL_GPIO_Init(BTN_Port,   &(LL_GPIO_InitTypeDef){ BTN_Pin, LL_GPIO_MODE_INPUT, 0, 0, LL_GPIO_PULL_UP });
}


void rdp_set(bool lock)
{
  FLASH_OBProgramInitTypeDef pOBInit;
  LL_FLASH_OBGetConfig(&pOBInit);
  bool lock_state = (pOBInit.RDPLevel == OB_RDP_LEVEL_1);

  if(lock_state != lock)                                                              // current state not same as requested
  {
    pOBInit.OptionType = OPTIONBYTE_RDP | OPTIONBYTE_USER;                            // Update user and RDP bits
    pOBInit.RDPLevel = lock ? OB_RDP_LEVEL_1 : OB_RDP_LEVEL_0;                        // Set RDP mode
/*
    if(lock)
    {
      pOBInit.USERConfig =  OB_RESET_MODE_GPIO |                                      // Disable Reset function, enable BOR
                            OB_BOR_ENABLE | OB_BOR_LEVEL_3p1_3p2 |                    // Enable BOR to 3.2V
                            OB_IWDG_SW | OB_WWDG_SW |                                 // Disable HW watchdog enforcement
                            OB_BOOT1_SRAM;                                            // When BOOT1=SRAM, BOOT0=1 boots from SRAM instead the bootloader
    }
    else
    {

      pOBInit.USERConfig =  OB_RESET_MODE_RESET |                                     // Disable Reset function, enable BOR
                            OB_BOR_DISABLE | OB_BOR_LEVEL_3p1_3p2 |                   // Disable BOR, set default level
                            OB_IWDG_SW | OB_WWDG_SW |                                 // Disable HW watchdog enforcement
                            OB_BOOT1_SYSTEM;                                          // When BOOT1=SYSTEM, BOOT0=1 boots the bootloader
    }
*/
    LL_FLASH_Unlock();                                                                // Unlock Flash
    LL_FLASH_OB_Unlock();                                                             // Unlock OB
    LL_FLASH_OBProgram(&pOBInit);                                                     // Program config. Going RDP1->RDP0 instantly wipes the entire system, but still need a cycling the power to reload the RDP config.
    LL_FLASH_OB_Launch();                                                             // Force OB reload (This normally restarts the system)
    NVIC_SystemReset();                                                               // Just in case
  }
}

void led_process(void)          // Toggle green led every 500ms
{
  static uint32_t ledTime;
  if(ledTime > getTick())
      return;
  ledTime = getTick()+500;
  TogglePin(GREEN);
}

bool button_update(void)        // Sample button every 1ms
{
  static uint32_t btnTime;
  static uint8_t debounce;
  static bool stable = 1;
  static bool last = 1;
  bool now;
  if(btnTime >= getTick())
    return stable;
  btnTime = getTick();
  now = ReadPin(BTN);
  if(last != now)
  {
    last = now;
    debounce=0;
  }
  else if(stable != now && ++debounce > 200)
    stable=now;
  return stable;
}

void button_process(void)
{
  if(!button_update()){       // Button reads 0 (Pressed)
    WritePin(GREEN,0);        // Set GREEN led on
    WritePin(RED,1);          // RED off
    rdp_set(DISABLE);         // Clear RDP. This will erase and crash the system, nothing else happens after this
  }
}

int main(void)
{
  BSP_RCC_HSI_PLL48MConfig();         // 48MHz PLL config
  SysTick_Config(48000);
  GPIO_init();                        // Init GPIO stuff
  rdp_set(ENABLE);                    // Set RDP0
  WritePin(RED,0);                    // Enable RED led to indicate locked RDP
  while (1)
  {
    led_process();
    button_process();
  }
}

#ifdef  USE_FUASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  while (1);
}
#endif /* USE_FUASSERT */

/**
  ******************************************************************************
  * @file    main.h
  * @author  MCU Application Team
  * @brief   Header for main.c file.
  *          This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) Puya Semiconductor Co.
  * All rights reserved.</center></h2>
  *
  * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
//#include "py32f0xx_hal.h"
#include "py32f0xx.h"
#include "py32f0xx_ll_adc.h"
#include "py32f0xx_ll_bus.h"
#include "py32f0xx_ll_cortex.h"
#include "py32f0xx_ll_dma.h"
#include "py32f0xx_ll_exti.h"
#include "py32f0xx_ll_flash.h"
#include "py32f0xx_ll_gpio.h"
#include "py32f0xx_ll_i2c.h"
#include "py32f0xx_ll_pwr.h"
#include "py32f0xx_ll_rcc.h"
#include "py32f0xx_ll_system.h"
#include "py32f0xx_ll_tim.h"
#include "py32f0xx_ll_usart.h"
#include "py32f0xx_ll_utils.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>


#if defined(USE_FULL_ASSERT)
#include "py32_assert.h"
#endif /* USE_FULL_ASSERT */

/* Private includes ----------------------------------------------------------*/

#define CON2(a,b)       a##b
#define WritePin(p,o)   CON2(p,_Port->BSRR) = CON2(p,_Pin)<<(o ? 0 : 16)
#define ReadPin(p)      ((CON2(p,_Port->IDR) & CON2(p,_Pin)) && 1)
#define TogglePin(p)    CON2(p,_Port->ODR) ^= CON2(p,_Pin)
#define setLED(l,s)     WritePin(l,!s)

#define RED_Port        GPIOB
  #define RED_Pin       LL_GPIO_PIN_0
#define GREEN_Port      GPIOA
  #define GREEN_Pin     LL_GPIO_PIN_0
#define BLUE_Port       GPIOB
  #define BLUE_Pin      LL_GPIO_PIN_1
#define BLUE_Port       GPIOB
  #define BLUE_Pin      LL_GPIO_PIN_1
#define SCL_Port        GPIOF
  #define SCL_Pin       LL_GPIO_PIN_1
  #define SCL_AF        LL_GPIO_AF12_I2C
#define SDA_Port        GPIOA
  #define SDA_Pin       LL_GPIO_PIN_7
  #define SDA_AF        LL_GPIO_AF12_I2C
#define TX_Port         GPIOA
  #define TX_Pin        LL_GPIO_PIN_2
//  #define TX_AF         LL_GPIO_AF4_USART2
  #define TX_AF         LL_GPIO_AF1_USART1
#define RX_Port         GPIOA
  #define RX_Pin        LL_GPIO_PIN_3
  #define RX_AF         LL_GPIO_AF1_USART1
/*
#define _Port        GPIO
  #define _Pin       LL_GPIO_PIN_
  #define _AF        LL_GPIO_AF
*/
/* Private defines -----------------------------------------------------------*/
/* Exported variables prototypes ---------------------------------------------*/
/* Exported functions prototypes ---------------------------------------------*/
void APP_ErrorHandler(void);
void led_interrupt(void);
#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT Puya *****END OF FILE******************/

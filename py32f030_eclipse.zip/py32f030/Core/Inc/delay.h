/*
 * delay.h
 *
 *  Created on: 11 jul. 2023
 *      Author: David
 */

#ifndef CORE_INC_DELAY_H_
#define CORE_INC_DELAY_H_

#include "main.h"

extern volatile uint32_t tick;
#define delay_ms(n) delay_ms_(n/10)

uint32_t getTick(void);
void delay_ms_(uint16_t ms);

#endif /* CORE_INC_DELAY_H_ */

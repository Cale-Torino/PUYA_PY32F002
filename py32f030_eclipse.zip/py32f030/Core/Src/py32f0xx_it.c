/**
  ******************************************************************************
  * @file    py32f0xx_it.c
  * @author  MCU Application Team
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) Puya Semiconductor Co.
  * All rights reserved.</center></h2>
  *
  * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "py32f0xx_it.h"

/* Private includes ----------------------------------------------------------*/

#include "delay.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private user code ---------------------------------------------------------*/
/* External variables --------------------------------------------------------*/

/******************************************************************************/
/*          Cortex-M0+ Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  while (1)
  {
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void){
}

void SysTick_Handler(void){
  tick++;
}

/*
void WWDG_IRQHandler(void){
}
*/

/*
void PVD_IRQHandler(void){
}
*/

/*
void RTC_IRQHandler(void){
}
*/

/*
void FLASH_IRQHandler(void){
}
*/

/*
void RCC_IRQHandler(void){
}
*/

/*
void EXTI0_1_IRQHandler(void){
}
*/

/*
void EXTI2_3_IRQHandler(void){
}
*/

/*
void EXTI4_15_IRQHandler(void){
}
*/

/*
void DMA1_Channel1_IRQHandler(void){

}
*/

/*
void DMA1_Channel2_3_IRQHandler(void){
}
*/

/*
void ADC_COMP_IRQHandler(void){
}
*/

/*
void TIM1_BRK_UP_TRG_COM_IRQHandler(void){
}
*/

/*
void TIM1_CC_IRQHandler(void){
}
*/

/*
void TIM3_IRQHandler(void){
}
*/

/*
void LPTIM1_IRQHandler(void){
}
*/

/*
void TIM14_IRQHandler(void){
}
*/

/*
void TIM16_IRQHandler(void){
}
*/

/*
void TIM17_IRQHandler(void){
}
*/

/*
void I2C1_IRQHandler(void){
}
*/

/*
void SPI1_IRQHandler(void){
}
*/

/*
void SPI2_IRQHandler(void){
}
*/

/*
void USART1_IRQHandler(void){
}
*/

/*
void USART2_IRQHandler(void){
}
*/

/*
void LED_IRQHandler(void){
}
*/

/******************************************************************************/
/* PY32F0xx Peripheral Interrupt Handlers                                     */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file.                                          */
/******************************************************************************/

/************************ (C) COPYRIGHT Puya *****END OF FILE******************/

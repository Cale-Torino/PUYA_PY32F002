#include "main.h"
#include "py32f0xx_bsp_clock.h"
#include "delay.h"

//__attribute__((section(".rdp"))) const uint32_t rdp = 0x4155beaa;
//__attribute__((section(".rdp"))) const uint32_t rdp = 0x41aabe55;

void led_init(){
  LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOA | LL_IOP_GRP1_PERIPH_GPIOB | LL_IOP_GRP1_PERIPH_GPIOF);
  setLED(RED,0);
  setLED(GREEN,0);
  setLED(BLUE,0);
  LL_GPIO_Init(RED_Port,   &(LL_GPIO_InitTypeDef){ RED_Pin, LL_GPIO_MODE_OUTPUT, LL_GPIO_SPEED_FREQ_VERY_HIGH, LL_GPIO_OUTPUT_PUSHPULL, LL_GPIO_PULL_NO });
  LL_GPIO_Init(GREEN_Port, &(LL_GPIO_InitTypeDef){ GREEN_Pin, LL_GPIO_MODE_OUTPUT, LL_GPIO_SPEED_FREQ_VERY_HIGH, LL_GPIO_OUTPUT_PUSHPULL, LL_GPIO_PULL_NO });
  LL_GPIO_Init(BLUE_Port,  &(LL_GPIO_InitTypeDef){ BLUE_Pin, LL_GPIO_MODE_OUTPUT, LL_GPIO_SPEED_FREQ_VERY_HIGH, LL_GPIO_OUTPUT_PUSHPULL, LL_GPIO_PULL_NO });
}
void led_process(void){
  static uint32_t ledTime;
  static uint8_t led;
  if(ledTime<getTick()){
    ledTime = getTick()+9;

    if(led>6)
      led=0;

    if(led==0){
      setLED(BLUE,0);   // yellow
      setLED(GREEN,1);
      setLED(RED,1);
    }
    else if(led==1){
      setLED(GREEN,0);  // red
    }
    else if(led==2){
      setLED(RED,0);    // green
      setLED(GREEN,1);
    }
    else if(led==3){
      setLED(BLUE,1);   // cyan
    }
    else if(led==4){    // purple
      setLED(RED,1);
      setLED(GREEN,0);
    }
    else if(led==5){     // blue
      setLED(RED,0);
    }
    else if(led==6){     // white
      setLED(RED,1);
      setLED(GREEN,1);
      setLED(BLUE,1);
    }
    /*
    else if(led==7){     // black
      setLED(RED,0);
      setLED(GREEN,0);
      setLED(BLUE,0);
    }
    */
    led++;
  }
}

const LL_DMA_InitTypeDef UART_DMAInit = {
    .PeriphOrM2MSrcAddress = (uint32_t)&USART1->DR,
    .MemoryOrM2MDstAddress = (uint32_t)&USART1->DR,
    //.MemoryOrM2MDstAddress = (uint32_t)&rx,
    .Direction = LL_DMA_DIRECTION_PERIPH_TO_MEMORY,
    .Mode = LL_DMA_MODE_CIRCULAR,
    .PeriphOrM2MSrcIncMode = LL_DMA_PERIPH_NOINCREMENT,
    .MemoryOrM2MDstIncMode = LL_DMA_MEMORY_NOINCREMENT,
    .PeriphOrM2MSrcDataSize = LL_DMA_PDATAALIGN_BYTE,
    .MemoryOrM2MDstDataSize = LL_DMA_MDATAALIGN_BYTE,
    .NbData=1,
    .Priority = LL_DMA_PRIORITY_VERYHIGH,
};

void init_uart(void){
  LL_USART_InitTypeDef USART_init  = { 115200, 8, 1, LL_USART_PARITY_NONE, LL_USART_DIRECTION_TX_RX, LL_USART_HWCONTROL_NONE, LL_USART_OVERSAMPLING_16 };

  LL_APB1_GRP2_EnableClock(LL_APB1_GRP2_PERIPH_SYSCFG);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_DMA1);

  LL_GPIO_Init(RX_Port, &(LL_GPIO_InitTypeDef){ RX_Pin, LL_GPIO_MODE_ALTERNATE, LL_GPIO_SPEED_FREQ_VERY_HIGH, 0, LL_GPIO_PULL_NO, RX_AF });
  LL_GPIO_Init(TX_Port, &(LL_GPIO_InitTypeDef){ TX_Pin, LL_GPIO_MODE_ALTERNATE, LL_GPIO_SPEED_FREQ_VERY_HIGH, 0, LL_GPIO_PULL_NO, TX_AF });

  LL_SYSCFG_SetDMARemap_CH1(LL_SYSCFG_DMA_MAP_USART1_RX);
  LL_DMA_DisableChannel(DMA1, LL_DMA_CHANNEL_1);
  LL_DMA_ClearFlag_GI2(DMA1);
  LL_DMA_Init(DMA1, LL_DMA_CHANNEL_1, (LL_DMA_InitTypeDef*)&UART_DMAInit);
  LL_DMA_EnableChannel(DMA1, LL_DMA_CHANNEL_1);

  LL_APB1_GRP2_EnableClock(LL_APB1_GRP2_PERIPH_USART1);
  LL_USART_Init(USART1, &USART_init);
  LL_USART_ClearFlag_TC(USART1);
  LL_USART_EnableDirectionRx(USART1);

  LL_USART_Enable(USART1);
  LL_USART_EnableDMAReq_RX(USART1);
}

void put_uart(char *s){
  while(*s){
    LL_USART_TransmitData8(USART1, *s++);
    while(!LL_USART_IsActiveFlag_TXE(USART1));
  }
}


int main(void)
{
  BSP_RCC_HSI_PLL48MConfig();
  SysTick_Config(480000);
  led_init();
  init_uart();


  put_uart("\r\nHello! This is a loop test using DMA!\r\nWaiting for incoming data...\r\n\n");
  delay_ms(500);
  while (1)
  {
    led_process();
  }
}
void ErrorHandler(void)
{
  while (1);
}

#ifdef  USE_FUASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  while (1);
}
#endif /* USE_FUASSERT */

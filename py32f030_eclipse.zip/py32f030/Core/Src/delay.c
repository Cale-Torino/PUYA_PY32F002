/*
 * delay.c
 *
 *  Created on: 11 jul. 2023
 *      Author: David
 */

#include "delay.h"


volatile uint32_t tick;

uint32_t getTick(void){
  return tick;
}

void delay_ms_(uint16_t ms){
    if(!ms) return;
    uint32_t t = SysTick->VAL;              // Current counter value
    uint32_t m = getTick()+ms-1;            // Future tick value -1
    if(t < SysTick->VAL) m++;               // Rollover detection
    while(m > getTick());                   // Wait for ms-1
    while(t < SysTick->VAL);                // Wait until counter value reaches same value as beginning (For best accuracy)
}
